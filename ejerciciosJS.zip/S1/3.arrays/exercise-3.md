Alerta el numero de elementos en el array usando la propiedad correcta de Array.

```js
const cars = ["Saab", "Volvo", "BMW"];
```

