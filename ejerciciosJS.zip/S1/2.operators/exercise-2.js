//Divide 10 por 2 y muestra el resultado en un alert.
alert(10/2);