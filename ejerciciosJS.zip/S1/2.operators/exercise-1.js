//Multiplica 10 por 5 y muestra el resultado mediante alert.
alert(10*5);