/*
Usa el correcto operador de asignación que resultará en
 ``x = 15``, teniendo dos variables ``y = 10`` y ``z = 5``.
*/

var y = 10;
var z = 5;
var x = y += z;

alert(x);