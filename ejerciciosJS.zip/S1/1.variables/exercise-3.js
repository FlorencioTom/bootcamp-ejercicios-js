//Crea una variable llamada x con el valor 5 y otra y con el valor 10. Crea una tercera variable z y asignale el valor de x + y.
var x = 5;
var y = 10;
var z = x + y;