//Crea una variable llamada carName, asignale el valor Volvo a ella.
var carName = "Volvo";