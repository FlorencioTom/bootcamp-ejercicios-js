/*
Dado el siguiente javascript, cambia el valor de la propiedad ``age`` a 25.
const character = {name: 'Jack Sparrow', age: 10};
*/
const character = {name: 'Jack Sparrow', age: 10};
character.age = 25;
//alert(character.age);