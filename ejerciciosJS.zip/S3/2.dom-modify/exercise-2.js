const miDiv = document.createElement('div');
const p = document.createElement('p');
miDiv.appendChild(p);
document.body.appendChild(miDiv);