const miDiv = document.createElement('div');
document.body.appendChild(miDiv);