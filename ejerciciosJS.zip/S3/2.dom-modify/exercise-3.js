const miDiv = document.createElement('div');
for(let i = 0; i<6; i++){
    miDiv.appendChild(document.createElement('p'));
}
document.body.appendChild(miDiv);