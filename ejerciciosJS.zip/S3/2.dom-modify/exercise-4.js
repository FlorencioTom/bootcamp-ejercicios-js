
let p = document.createElement('p');
p.innerHTML = 'Soy dinamico';
document.body.appendChild(p);